import numpy as np
import pandas as pd
from flask import Flask, jsonify, request, render_template
import pickle
# from xgboost import XGBClassifier

# load model
modelCured = pickle.load(open('cured-adaboost-model.pkl','rb'))
modelDeceased = pickle.load(open('deceased-adaboost-model.pkl','rb'))

# app
app = Flask(__name__)

# routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/recovery')
def homeRecovery():
    return render_template('index-cured.html')

@app.route('/predict/recovery', methods=['POST'])
def predictRecovery():
    int_features = [x for x in request.form.values()]
    final_features = [np.array(int_features)]
    prediction = modelCured.predict(final_features)

    output = round(prediction[0], 2)

    if(output == 1):
        prediction_text = "This individual has high recovery rate when it comes to atherosclerotic heart disease"
    else:
        prediction_text = "This individual has low recovery rate when it comes to atherosclerotic heart disease"

    return render_template('index-cured.html', prediction_text=prediction_text)

@app.route('/predict/mortality', methods=['POST'])
def predictMortality():
    int_features = [x for x in request.form.values()]
    final_features = [np.array(int_features, dtype=object)]
    prediction = modelDeceased.predict(final_features)

    output = round(prediction[0], 2)

    if(output == 1):
        prediction_text = "This individual has high mortality rate when it comes to atherosclerotic heart disease"
    else:
        prediction_text = "This individual has low mortality rate when it comes to atherosclerotic heart disease"

    return render_template('index.html', prediction_text=prediction_text)

if __name__ == '__main__':
    app.run(port = 5000, debug=True)